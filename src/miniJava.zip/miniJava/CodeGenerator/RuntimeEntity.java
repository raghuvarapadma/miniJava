package miniJava.CodeGenerator;

public abstract class RuntimeEntity {
	public int size;
	public RuntimeEntity() {
		size = 0;
	}
	public RuntimeEntity (int size) {
		this.size = size;
	}
}
