package miniJava.SyntacticAnalyzer;

public class SyntaxException extends Exception {
	public SyntaxException() {
		super();
	}
	public SyntaxException(String exceptionMessage) {
		super(exceptionMessage);
	}
}
