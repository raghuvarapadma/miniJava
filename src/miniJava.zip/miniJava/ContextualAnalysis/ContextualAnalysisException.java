package miniJava.ContextualAnalysis;

public class ContextualAnalysisException extends RuntimeException {
	public ContextualAnalysisException() {
		super();
	}
	public ContextualAnalysisException(String exceptionMessage) {
		super(exceptionMessage);
	}
}
